@echo off
title Cashier Installer
color 0A

set "ZIP=%TEMP%\Cashier.zip"
set "FOLDER=%TEMP%\CashierInstall"

echo Downloading Cashier...

powershell -Command ^
"Invoke-WebRequest 'https://github.com/zadelrahmanzad-boop/EH/raw/refs/heads/main/Cashier.zip' -OutFile '%ZIP%'"

if not exist "%ZIP%" (
    echo Download failed
    pause
    exit
)

echo Extracting files...

powershell -Command ^
"Expand-Archive -Path '%ZIP%' -DestinationPath '%FOLDER%' -Force"

echo Cleaning ZIP...
del "%ZIP%" /f /q

echo Starting Cashier...

start "" "%FOLDER%\Cashier.exe"

timeout /t 5 >nul

echo Cleaning temp files...

rd /s /q "%FOLDER%"

:: حذف ملف Install_Cashier.zip
del "%~dp0Install_Cashier.zip" /f /q

exit
